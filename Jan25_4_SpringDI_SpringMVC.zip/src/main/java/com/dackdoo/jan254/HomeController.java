package com.dackdoo.jan254;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dackdoo.jan254.fruit.Fruit;
import com.dackdoo.jan254.member.MemberDAO;

@Controller
public class HomeController {
	
	@Autowired
	private Fruit f;
	
	@Autowired
	private MemberDAO mDAO;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		System.out.println(f.getName());
		System.out.println(f.getPrice());
		mDAO.test();
		return "home";
	}
	
}
// @Annotation : 사전적 의미로는 '주석'
//		코드 사이에 주석처럼 쓰이면서 기능을 수행하도록 하는 기술
//			- 코드 작성 문법에러를 체크하도록 정보를 제공
//			- 개발 툴이 코드를 자동으로 생성할 수 있도록
//			- 실행시 특정한 기능을 수행하도록

//	종류
//		1. @Bean
//			직접 제어가 불가능한 외부 라이브러리 등을 Bean으로 만드려고 할 때 사용
//			ex) sqlsession / sqlsessionTemplete
//		2. @Autowired
//			속성, setter, 생성자에서 사용, 타입에 따라서 Bean을 주입해준다(의존성 주입)
//		3. @Controller
//			말 그대로 Controller
//		4. @RestController
//			Controller 중에서 View로 응답하지 않는 Controller
//			data(json, xml) return이 주 목적!
//		5. @ResponseBody
//			자바 객체를 HTTP요청의 body의 내용으로 mapping하는 역할
//		=> @RestController = @Controller + @ResponseBody

//		6. @Service
//			어떤 기능을 수행하는 Class를 나타내는 용도(어지간한 DAO에 다씀)
//		7. @XmlRootElement / @XmlElement	// xml파싱하는데 사용함.
//			특정한 데이터를 XML형식으로 만드는데 사용(마샬링 : Mashalling)
//			그 반대도 가능(언마샬링 : Unmashalling)
//			XmlRootElement : Javabean 객체의 Class명에 명시
//			XmlElement : Javabean 객체의 setter에 명시
//		8. @RequestMapping
//			요청에 따라 어떤 Controller, 어떤 Method가 구현될지 mapping하기 위해서 사용
//			value : 요청받을 주소(url)을 설정
//			method : 어떤 방식으로 요청을 받을지 설정(GET, POST)
//		9. @RequestParam
//			요청 파라미터 설정





















