package com.dackdoo.jan254.member;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// 사이트에서 연/월/일 -> 연-월-일 시:분:초

// servlet-context.xml에 MemberDAO를 등록한 효과!
@Service
public class MemberDAO {
	
	@Autowired
	private SimpleDateFormat sdf;
	
	public void test() {
		Date now = new Date();
		System.out.println(sdf.format(now));
	}
	
}

































