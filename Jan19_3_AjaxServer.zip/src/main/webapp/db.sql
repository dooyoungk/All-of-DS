create table jan19_fruit(
	f_name varchar2(10 char) primary key,
	f_price number(5) not null
);

insert into jan19_fruit values('����', 4000);
insert into jan19_fruit values('���', 3000);
insert into jan19_fruit values('���θӽ�Ĺ', 14000);
insert into jan19_fruit values('�ٳ���', 5000);

select * from jan19_fruit;
