package com.dackdoo.jan193.fruit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.dackoo.db.manager.DackdooDBManager;

public class FruitDAO {
	public static void getAllFruit(HttpServletRequest req) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = DackdooDBManager.connect("DeadPool");
			String sql = "select * from jan19_fruit order by f_name";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			ArrayList<Fruit> fruits = new ArrayList<Fruit>();
			Fruit fruit = null;
			
			while (rs.next()) {
				fruit = new Fruit();
				fruit.setF_name(rs.getString("f_name"));
				fruit.setF_price(rs.getInt("f_price"));
				fruits.add(fruit);
			}
			req.setAttribute("fruits", fruits);
		} catch (Exception e) {
			DackdooDBManager.close(con, pstmt, rs);
		}
	}
}











