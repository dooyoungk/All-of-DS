$(function() {
	connectSearchAddressEvent();
	connectIdCheckEvent();
	noticeEvent();
});

function noticeEvent() {
	var noticeVisible = false;
	$("#noticeHandle").click(function() {
		if(!noticeVisible){
			$("#siteNoticeArea").css("left", "-330px");
		} else {
			$("#siteNoticeArea").css("left", "0px");
		}
		noticeVisible = !noticeVisible;
	});
}

function connectIdCheckEvent() {
	// rgb(255, 0, 0)
	// a라고 썼는데, a가 DB에 있나?(ID가 중복되나?)
	// keydown : a가 적히기 전
	// keyup : a가 적히고 나서
	$("#signup_gs_id").keyup(function() {
		var gs_id = $(this).val();
		// JavaScript + DB연동
		$.getJSON("member.id.check?gs_id=" + gs_id, function(memberJSON) {
			if (memberJSON.member[0] == null){
				$("#signup_gs_id").css("color", "black");
			} else {
				$("#signup_gs_id").css("color", "red");
			}
		});
	});
}

function connectSearchAddressEvent() {
	$("#signup_gs_addr1, #signup_gs_addr2").click(function() {
		new daum.Postcode({
	        oncomplete: function(data) {
	        	$("#signup_gs_addr1").val(data.zonecode);
	        	$("#signup_gs_addr2").val(data.roadAddress);
	        }
	    }).open();
	});
}

