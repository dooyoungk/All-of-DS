function signupCheck() {
	var idInput = document.signupForm.gs_id;
	var pwInput = document.signupForm.gs_pw;
	var pwChkInput = document.signupForm.gs_pwChk;
	var nameInput = document.signupForm.gs_name;
	var addr1Input = document.signupForm.gs_addr1;
	var addr2Input = document.signupForm.gs_addr2;
	var addr3Input = document.signupForm.gs_addr3;
	var photoInput = document.signupForm.gs_photo;

	// 안썼거나 글자가 빨간색이면
	if (isEmpty(idInput) || $("#signup_gs_id").css("color") == "rgb(255, 0, 0)") {
		alert("Please Fill in your ID properly.");
		idInput.value = "";
		idInput.focus();
		return false;
	} else if (isEmpty(pwInput) || notEqualPw(pwInput, pwChkInput)
			|| notContains(pwInput, "1234567890")) {
		alert("Please Fill in your Password properly.");
		pwInput.value = "";
		pwChkInput.value = "";
		pwInput.focus();
		return false;
	} else if (isEmpty(nameInput)) {
		alert("Please Fill in your Name properly.");
		nameInput.value = "";
		nameInput.focus();
		return false;
	} else if (isEmpty(addr1Input) || isEmpty(addr2Input)
			|| isEmpty(addr3Input)) {
		alert("Please Fill in your Address properly.");
		addr1Input.value = "";
		addr2Input.value = "";
		addr3Input.value = "";
		addr3Input.focus();
		return false;
	} else if (isEmpty(photoInput)
			|| (isNotType(photoInput, "png") 
					&& isNotType(photoInput, "gif")
					&& isNotType(photoInput, "jpg")
					&& isNotType(photoInput, "jpeg")
					&& isNotType(photoInput, "bmp")
					&& isNotType(photoInput, "PNG")
					&& isNotType(photoInput, "GIF")
					&& isNotType(photoInput, "JPG") 
					&& isNotType(photoInput, "JPEG")
					&& isNotType(photoInput, "BMP"))) {
		alert("Please Fill in your Profile Picture properly.");
		photoInput.value = "";
		photoInput.focus();
		return false;
	}
	return true;
}