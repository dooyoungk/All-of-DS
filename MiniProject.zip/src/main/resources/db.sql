-- 권한
--		가입할때 자율 		-> 잘못된게 생김
--		관리자가 부여해주는 	-> 관리자 페이지를 만들어야..
--		합쳐진(자율인데, 관리자가 수정 가능)

--		관리자는 누구?

drop table golfsite_member cascade constraint purge;

create table golfsite_member(
	gs_id varchar2(15 char) primary key,
	gs_pw varchar2(12 char) not null,
	gs_name varchar2(10 char) not null,
	gs_addr varchar2(200 char) not null,
	gs_photo varchar2(100 char) not null,
	gs_role char(1 char) not null
);

select * from golfsite_member