package com.beaver.mp.golf;

import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

//servlet-context.xml에 등록해주는것과 같은 효과
@Service
public class MemberDAO {
// Spring : .java에 안하고 다른파일에 객체만들기 (=IoC)
//			servlet-context.xml에 SqlSession객체 만들어놨음
//			servlet-context.xml에 MemberDAO객체도 하나 만들어짐 -> 8번줄 때문에

	// servlet-context.xml에 등록해놓은거 가져오기
	@Autowired
	private SqlSession ss;

	public void signup(Member m, HttpServletRequest req) {
		try {
			String path = req.getSession().getServletContext().getRealPath("resources/img");
			System.out.println(path);
			MultipartRequest mr = new MultipartRequest(req, path, 10 * 1024 * 1024, "utf-8",
					new DefaultFileRenamePolicy());
			m.setGs_id(mr.getParameter("gs_id"));
			m.setGs_pw(mr.getParameter("gs_pw"));
			m.setGs_name(mr.getParameter("gs_name"));
			m.setGs_role(mr.getParameter("gs_role"));

			String gs_addr1 = mr.getParameter("gs_addr1"); // 우편번호
			String gs_addr2 = mr.getParameter("gs_addr2"); // 주소
			String gs_addr3 = mr.getParameter("gs_addr3"); // 상세주소
			String gs_addr = gs_addr2 + "!" + gs_addr3 + "!" + gs_addr1; // 나중에 spilt하기 편하게
			m.setGs_addr(gs_addr);
			System.out.println(m.getGs_id());
			System.out.println(m.getGs_pw());
			System.out.println(m.getGs_name());
			System.out.println(m.getGs_role());
			System.out.println(m.getGs_addr());
			
			String gs_photo = mr.getFilesystemName("gs_photo"); // 지울때는 한글처리 안된걸로 지우기위해서
//			String gs_photo = mf.getOriginalFilename(); 
			String gs_photo_kor = URLEncoder.encode(gs_photo,"utf-8").replace("+", " ");
			m.setGs_photo(gs_photo_kor);

			// GolfMapper 불러다가 거기있는 signup메소드 호출
			if (ss.getMapper(GolfMapper.class).signup(m) == 1) {
				req.setAttribute("r", "가입성공");	
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r", "가입실패");
		}
	}

	public Members memberIdCheck(Member m) {
		return new Members(ss.getMapper(GolfMapper.class).getMemberById(m));
	}
	
	public void login(Member idInput, HttpServletRequest req) {
		try {
			List<Member> members = ss.getMapper(GolfMapper.class).getMemberById(idInput);
			if (members.size() != 0) {
				Member dbM = members.get(0);
				System.out.println(dbM.getGs_id());
				if (dbM.getGs_pw().equals(idInput.getGs_pw())) {
					req.setAttribute("r", "로그인성공");
					req.getSession().setAttribute("loginMember", dbM);
					req.getSession().setMaxInactiveInterval(10 * 60);
				} else {
					req.setAttribute("r", "로그인실패(PW오류)");
				}
			} else {
				req.setAttribute("r", "로그인실패(미가입ID)");
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r", "로그인실패(DB서버문제)");
		}
	}
	
//	public boolean loginCheck(HttpServletRequest req) {
//		Member m = (Member) req.getSession().getAttribute("loginMember");
//		if (m != null) {
//			req.setAttribute("loginPage", "member/loginSuccess.jsp");
//			return true;
//		} else {
//			req.setAttribute("contentPage", "member/login.jsp");
//			return false;
//		}
//	}
}
