package com.beaver.mp.golf;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MemberController {
	
	@Autowired
	private MemberDAO mDAO;
	
	@RequestMapping(value = "/member.signup.go", method = RequestMethod.GET)
	public String memberSignupGo(Member m, HttpServletRequest req) {
		req.setAttribute("contentPage", "member/signup.jsp");
		return "index";
	}
	
	
	@RequestMapping(value = "/member.signup", method = RequestMethod.POST)
	public String memberSignup(Member m, HttpServletRequest req) {
		mDAO.signup(m, req);
		req.setAttribute("contentPage", "home.jsp");
		return "index";
	}

	@RequestMapping(value = "/member.id.check", method = RequestMethod.GET)
	public @ResponseBody Members memberIdCheck(Member m) {
		return mDAO.memberIdCheck(m);
	}
}
