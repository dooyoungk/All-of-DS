package com.beaver.mp.golf;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {
	@Autowired
	private MemberDAO mDAO;
	
	@RequestMapping(value = "/member.id.check", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	public @ResponseBody Members memberIdCheck(Member m) {
		return mDAO.memberIdCheck(m);
	}
	
	@RequestMapping(value = "/member.login.go", method = RequestMethod.GET)
	public String memberLoginGo(Member m, HttpServletRequest req) {
		req.setAttribute("contentPage", "member/login.jsp");
		return "index";
	}
	
	@RequestMapping(value = "/member.login", method = RequestMethod.POST)
	public String memberLogin(Member m, HttpServletRequest req) {
		mDAO.login(m, req);
		// mDAO.loginCheck(req);
		req.setAttribute("contentPage", "home.jsp");
		return "index";
	}
}
