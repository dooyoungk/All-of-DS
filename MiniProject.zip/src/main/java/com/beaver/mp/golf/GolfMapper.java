package com.beaver.mp.golf;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface GolfMapper {
	public abstract int signup(Member m);
	public abstract List<Member> getMemberById(Member m);
}
