create table carbon(
	c_location varchar2(10 char) primary key,
	c_name varchar2(10 char) not null,
	c_color varchar2(10 char) not null,
	c_weight number(5, 2) not null,
	c_type varchar2(10 char) not null
);

insert into carbon values('6', 'ź��', '����', 12, '��ü');
select * from carbon;