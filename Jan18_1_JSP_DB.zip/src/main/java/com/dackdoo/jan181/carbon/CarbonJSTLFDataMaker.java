package com.dackdoo.jan181.carbon;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.dackoo.db.manager.DackdooDBManager;

public class CarbonJSTLFDataMaker {
	
	private static final CarbonJSTLFDataMaker CarbonDAO = new CarbonJSTLFDataMaker();
	
	public CarbonJSTLFDataMaker() {
		// TODO Auto-generated constructor stub
	}
	
	
	public static CarbonJSTLFDataMaker getCarbondao() {
		return CarbonDAO;
	}


	public void getAllcarbon(HttpServletRequest req) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = DackdooDBManager.connect("DeadPool");
			// sql�� �ۼ�
			String sql = "select * from carbon order by c_location";
			pstmt = con.prepareStatement(sql);
			
			// C / U / D : pstmt.executeUpdate()�� ���� -> ������ � ������ �޾Ҵ���
			// R : pstmt.executeQuery()�� ���� -> select����� ResultSet���� ����
			rs = pstmt.executeQuery();
			
			ArrayList<Carbon> carbons = new ArrayList<Carbon>();
			Carbon carbon = null;
			
			while (rs.next()) {
				carbon = new Carbon();
				carbon.setC_location(rs.getString("c_location"));
				carbon.setC_name(rs.getString("c_name"));
				carbon.setC_color(rs.getString("c_color"));
				carbon.setC_weight(rs.getDouble("c_weight"));
				carbon.setC_type(rs.getString("c_type"));
				carbons.add(carbon);
			}
			req.setAttribute("carbons", carbons);
			
		} catch (Exception e) {
			DackdooDBManager.close(con, pstmt, rs);
		}
	}
}
