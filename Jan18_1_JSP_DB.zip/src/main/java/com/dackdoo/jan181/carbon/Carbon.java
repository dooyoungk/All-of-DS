package com.dackdoo.jan181.carbon;

public class Carbon {
	private String c_location;
	private String c_name;
	private String c_color;
	private double c_weight;
	private String c_type;
	
	public Carbon() {
		// TODO Auto-generated constructor stub
	}

	public Carbon(String c_location, String c_name, String c_color, double c_weight, String c_type) {
		super();
		this.c_location = c_location;
		this.c_name = c_name;
		this.c_color = c_color;
		this.c_weight = c_weight;
		this.c_type = c_type;
	}

	public String getC_location() {
		return c_location;
	}

	public void setC_location(String c_location) {
		this.c_location = c_location;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getC_color() {
		return c_color;
	}

	public void setC_color(String c_color) {
		this.c_color = c_color;
	}

	public double getC_weight() {
		return c_weight;
	}

	public void setC_weight(double c_weight) {
		this.c_weight = c_weight;
	}

	public String getC_type() {
		return c_type;
	}

	public void setC_type(String c_type) {
		this.c_type = c_type;
	}
	
	
	
	
}
