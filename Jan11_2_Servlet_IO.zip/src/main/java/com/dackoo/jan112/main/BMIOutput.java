package com.dackoo.jan112.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BMIOutput")
public class BMIOutput extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("EUC-KR");
		response.setCharacterEncoding("EUC-KR");
		
		String name = request.getParameter("NAME");
		Double height = Double.parseDouble(request.getParameter("HEIGHT"));
		Double weight = Double.parseDouble(request.getParameter("WEIGHT"));
		Double bmi = weight / (0.01*height) * (0.01*height);
		
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<head><meta charset='euc-kr'></head>");
		out.print("<body>");
		out.print("<h1>BMI���</h2>");
		out.printf("<h2>�̸�: %s</h2>", name);
		out.printf("<h2>Ű: %.2f</h2>", height);
		out.printf("<h2>������: %.2f</h2>", weight);
		out.print("<hr>");
		out.printf("<h2>BMI: %.2f</h2>", bmi);
		out.print("</body>");
		out.print("</html>");
	}

}
