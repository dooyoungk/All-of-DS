package com.dackdoo.jan134.main;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RCP_C")
public class RCP_C extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (!request.getParameterNames().hasMoreElements()) {
			request.setAttribute("mh", "css/Ready.gif");
			request.setAttribute("yh", "css/Ready.gif");
		} else {
			RCP_M rm = RCP_M.getRm();
			rm.RCPgame(request);
		}
		request.getRequestDispatcher("RCPView.jsp").forward(request, response);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
