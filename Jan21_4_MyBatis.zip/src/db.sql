create table jan21_fruit(
	f_name varchar2(10 char) primary key,
	f_price number(5) not null
);

insert into jan21_fruit values('사과', 3000);
insert into jan21_fruit values('귤', 4000);
insert into jan21_fruit values('바나나', 5000);

select * from jan21_fruit order by f_price; 