package com.dackdoo.jan214.main;

//							DB서버연결						SQL문
// Java : JDBC				.java						.java
// JSP : ConnectionPool		META-INF/context.xml(튜브)	.java
// MyBatis 					xxx.xml						yyy.xml

// MyBatis(ver3.x : MyBatis / ver2.x : iBatis)
//		Java와 SQL사이의 자동 매핑 기능을 지원하는 ORM 프레임워크
//		ORM(Object Relationship Mapping)
//		Framework : '틀'(사람을 컨트롤)을 제공
//			vs
//		Library : 사람이 필요할 때 가져다 쓰는!(사람이 컨트롤)

// mybatis.jar
// ojdbc8.jar 


public class MBMain {
	public static void main(String[] args) {
		
	}
}
