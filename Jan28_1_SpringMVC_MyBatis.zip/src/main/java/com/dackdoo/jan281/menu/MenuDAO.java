package com.dackdoo.jan281.menu;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@Service
public class MenuDAO {
	@Autowired
	private SqlSession ss;
	
	// sql insert문을 수행할 method
	public void reg(Menu m, HttpServletRequest req) {
		// 사진 업로드
		String path = null;
		MultipartRequest mr = null;	// MR파트에서는 JSP방식으로만 가능한듯. Spring방식으로 바로 getName이 안되는듯. setName을 해주기 위해 변환과정이 필요함.
		try {
			path = req.getSession().getServletContext().getRealPath("resources/img");	// JSP에서는 getSession()이 없었음. Spring에서는 필요. error남.
			mr = new MultipartRequest(req, // 원래 요청객체
					path, // 실행되는 서버상에서 파일 업로드될 폴더의 절대경로
					10 * 1024 * 1024, // 업로드하는 파일의 허용 최대 용량 (byte단위)
					"UTF-8", // POST방식 요청파라미터 한글처리
					new DefaultFileRenamePolicy()); // 파일명 중복시에 1, 2, 3, 4,.. 중복 막아주는
			
			String m_name = mr.getParameter("m_name");
			int m_price = Integer.parseInt(mr.getParameter("m_price"));
			String m_pic = mr.getFilesystemName("m_pic"); // 중복처리가 된 서버상의 실제 파일명
															// (ㅋ ㅋ2.png)
			m_pic = URLEncoder.encode(m_pic, "UTF-8");		// 톰캣이 한글파일명 인식을 못해서  URLEncoding
															// (%5A+%5A2.png)
			m_pic = m_pic.replace("+", " ");				// 띄어쓰기는 +로 바꾸기에는 쫌... 여러개일 경우 합쳐질 수도 있음.
															// (%5A %5A2.png)
			
			m.setM_name(m_name);
			m.setM_price(new BigDecimal(m_price));
			m.setM_pic(m_pic);
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r", "사진등록실패(용량초과)");
			return;			// 업로드 실패의 경우  db작업 안하게
		}
		
		// 사진, 메뉴명, 메뉴가격 java스럽게 변환해줘야함.
		
		
		try {
			if (ss.getMapper(MenuMapper.class).regMenu(m)==1) {
				req.setAttribute("r", "메뉴등록성공");
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r", "메뉴등록실패");
			return;
		}
	}

	// sql select문을 수행할 method
	public void getAllmenu(HttpServletRequest req) {
		try {
			List<Menu> menulist = ss.getMapper(MenuMapper.class).getAllmenu();
			req.setAttribute("menulist", menulist);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
