package com.dackdoo.jan281.menu;

import java.util.List;

public interface MenuMapper {
	public abstract int regMenu(Menu m);
	public abstract List<Menu> getAllmenu();
}
