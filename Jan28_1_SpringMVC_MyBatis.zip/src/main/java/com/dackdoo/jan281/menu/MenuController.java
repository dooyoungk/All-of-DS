package com.dackdoo.jan281.menu;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MenuController {
	
	//autowired로 menuDAO 객체필요
	@Autowired
	private MenuDAO mDAO;
	
	
	@RequestMapping(value="/menu.reg", method=RequestMethod.POST)
	public String reg(Menu m, HttpServletRequest req) {
		
		//menuDAO 등록메소드(insert), 출력메소드(select) 필요함 
		mDAO.reg(m, req);
		mDAO.getAllmenu(req);
		return "index";
	}
}
