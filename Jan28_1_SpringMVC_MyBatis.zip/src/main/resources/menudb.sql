create table jan28_menu(
	m_name varchar2(20 char) primary key,
	m_price number(5) not null,
	m_pic varchar2(200 char) not null
);

select * from jan28_menu;