package com.dackdoo.jan262.convert;

public class ConResult {
	private double x;
	private double y;
	private String before;
	private String after;
	
	public ConResult() {
		// TODO Auto-generated constructor stub
	}

	public ConResult(double x, double y, String before, String after) {
		super();
		this.x = x;
		this.y = y;
		this.before = before;
		this.after = after;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public String getBefore() {
		return before;
	}

	public void setBefore(String before) {
		this.before = before;
	}

	public String getAfter() {
		return after;
	}

	public void setAfter(String after) {
		this.after = after;
	}
	
	
	
	
}
