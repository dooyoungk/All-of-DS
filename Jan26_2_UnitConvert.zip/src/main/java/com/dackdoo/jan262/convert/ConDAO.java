package com.dackdoo.jan262.convert;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

@Service
public class ConDAO { 
	public void convert(ConResult cr, HttpServletRequest req) {
		double yy = 0;
		
		if (req.getParameter("unit").equals("cm")) {
			cr.setY(cr.getX() * 0.39);
			yy = cr.getY();
			cr.setBefore("cm");
			cr.setAfter("inch");
			req.setAttribute("r", cr.getX() + cr.getBefore());
			req.setAttribute("r2", yy + cr.getAfter());	
		} 	
		else if (req.getParameter("unit").equals("m2")) {
			cr.setY(cr.getX() * 0.3);
			yy = cr.getY();
			cr.setBefore("㎡");
			cr.setAfter("평");
			req.setAttribute("r", cr.getX() + cr.getBefore());
			req.setAttribute("r2", yy + cr.getAfter());
		} 
		else if (req.getParameter("unit").equals("c")) {
			cr.setY((cr.getX() * 1.8) + 32);
			yy = cr.getY();
			cr.setBefore("℃");
			cr.setAfter("℉");
			req.setAttribute("r", cr.getX() + cr.getBefore());
			req.setAttribute("r2", yy + cr.getAfter());
		}
		else if (req.getParameter("unit").equals("mih")) {
			cr.setY(cr.getX() * 1.61);
			yy = cr.getY();
			cr.setBefore("mi/h");
			cr.setAfter("km/h");
			req.setAttribute("r", cr.getX() + cr.getBefore());
			req.setAttribute("r2", yy + cr.getAfter());
		}	
		
	}
}
