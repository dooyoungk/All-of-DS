package com.dackdoo.jan262.convert;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ConvController {
	@Autowired
	private ConDAO cv;
	
	@RequestMapping(value="/convert.do", method = RequestMethod.GET)
	public String convXY(ConResult cr, HttpServletRequest req) {
		// 단위에 맞게 cv.convert를 불러야함. ConDAO객체를 한번만 부르면 다 실행됨.
		cv.convert(cr, req);
		return "output";
	}
}
