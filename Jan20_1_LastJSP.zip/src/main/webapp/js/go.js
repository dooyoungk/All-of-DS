function signUpGo() {
	location.href = "LoginController";
}