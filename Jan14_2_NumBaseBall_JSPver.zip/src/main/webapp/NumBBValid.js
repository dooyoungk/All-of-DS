function check() {
	let numchk = document.bbf.bbnum;

	if (isEmpty(numchk) || atLeastLetter(numchk, 3) || isNotNumber(numchk)) {
		alert("Please fill in your number Properly.");
		numchk.value = "";
		numchk.focus();
		return false;
	} else if (numchk.value[0] == numchk.value[1] || numchk.value[0] == numchk.value[2] || numchk.value[1] == numchk.value[2]) {
		alert("Your number duplicated. Please fix it Properly");
		numchk.value = "";
		numchk.focus();
		return false;
	}

	return true;
}