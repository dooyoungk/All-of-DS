package com.dackdoo.jan142.main;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;

public class NumBB_Model {
	private int time = 0;
	private String ans;

	private static final NumBB_Model nm = new NumBB_Model();

	public NumBB_Model() {
		// TODO Auto-generated constructor stub
	}

	public static NumBB_Model getNm() {
		return nm;
	}

	public void pickNum() {
		int ran_num = new Random().nextInt(976) + 12;
		String r_num = String.format("%03d", ran_num);
		
		if (r_num.charAt(0)==r_num.charAt(1) || r_num.charAt(0)==r_num.charAt(2) || r_num.charAt(1)==r_num.charAt(2)) {
			pickNum();
			return;
		}
		this.ans = r_num;
	}
		
	public void getNum(HttpServletRequest request) {
		int strike = 0;
		int ball = 0;

		String num = request.getParameter("bbnum");
		request.setAttribute("mynum", num);

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (ans.charAt(i) == num.charAt(j)) {
					if (i == j) {
						strike++;
					} else {
						ball++;
					}
				}
			}
		}
		time++;

		request.setAttribute("time", time + "��° �õ� !");
		request.setAttribute("strike", strike);
		request.setAttribute("ball", ball);
		if (strike==3) {
			String result = "����! " + ans + " �̾����ϴ�";
			request.setAttribute("result", result);
		}

	}
}
