package com.dackdoo.test.model;

import lombok.Builder;
import lombok.Data;

@Builder @Data
public class HobbyModel {
	private String hobby_no;
	private String hobby_nm;
}
