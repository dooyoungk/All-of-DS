package com.dackdoo.test.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dackdoo.test.mapper.UserMapper;
import com.dackdoo.test.model.AlldtoModel;
import com.dackdoo.test.model.BossModel;

@Service
public class UserService {
	@Autowired
	private SqlSession ss;
	//@Autowired
	//public UserMapper uMapper;
	
	
	// �̸��˻�
	public void searchUserName(AlldtoModel alldtoModel, HttpServletRequest req) {
		try {
			List<AlldtoModel> users = ss.getMapper(UserMapper.class).searchUserName(alldtoModel);
			req.setAttribute("users", ss.getMapper(UserMapper.class).searchUserName(alldtoModel));			
			System.out.println(users);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// ��������ȸ
	public List<BossModel> getAllUser(BossModel bossModel, HttpServletRequest req) {
		try {
			List<BossModel> ul = ss.getMapper(UserMapper.class).getAllUser(bossModel);
			req.setAttribute("ul", ss.getMapper(UserMapper.class).getAllUser(bossModel));			
			System.out.println(ul);
			return ul;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void regUser(BossModel bossModel, HttpServletRequest req) {
		try {
			List<BossModel> deptList = ss.getMapper(UserMapper.class).regUser(bossModel);
			req.setAttribute("deptList", ss.getMapper(UserMapper.class).regUser(bossModel));	
			System.out.println(deptList);
						
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
