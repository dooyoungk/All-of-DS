package com.dackdoo.jan261;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

// JSP Model 2------------------------
// http://IP:port/프로젝트명/컨트롤러파일명
//	C : Servlet
//		상황판단 -> 흐름제어
//		doGet(), doPost()를 활용
//		주소에 컨트롤러파일명, 컨트롤러 하나당 GET하나, POST하나 -> 컨트롤러 수가 많음
// Spring MVC-------------------------
// C : 일반 클래스
//		일반 메소드
//		컨트롤러 하나에 여러개의 요청 처리 가능 -> 컨트롤러가 많이 필요 없어짐

@Controller
public class HomeController {
	
	// go.home.lalala라는 주소로 GET방식 요청이 들어오면 이 메소드가 실행
	@RequestMapping(value = "/go.home.lalala", method = RequestMethod.GET)
	public void goHomeLalala() {
		System.out.println("랄랄라~~~ 수요일이다 ~~~");
	}
	
	@RequestMapping(value = "/dackdoo.ddd.yeah", method = RequestMethod.GET)
	public void gogogo() {
		int x = 5;
		int y = 6;
		System.out.println(x+y);
	}
	
	// jsp파일 -> input 3개 (이름 / x / y) + button
	// 사이트 첫 접속시 method : value에 아무것도 적지 않는다!
	@RequestMapping(value ="/", method = RequestMethod.GET)		
	public String goHome() {	// return 타입으로 String 자료형이 기본
		return "index";			// index.jsp로 포워딩
	}
	
}
