package com.dackdoo.jan261.calc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

@Service // servlet-context.xml에 CalcDAO객체 하나 등록한 효과
public class CalcDAO {
	public void calculate(CalcResult cr, HttpServletRequest req) {
		int add = cr.getX() + cr.getY();
		req.setAttribute("r", add);
	}
}
