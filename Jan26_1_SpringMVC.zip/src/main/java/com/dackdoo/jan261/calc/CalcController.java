package com.dackdoo.jan261.calc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

// 새 패키지를 만들 때는 top-level package뒤에 추가
// com.dackdoo.jan261.calc - O
// com.dackdoo.calc - X
// com.calc - X
// calc - X

@Controller
public class CalcController {
	
	@Autowired // servlet-context.xml에 등록된 CalcDAO객체와 자동으로 연결(3번 spring 스타일)
	private CalcDAO cd;
	
	
	// 1. JSP스타일 - 파일업로드, 날짜, ... -> Spring이 있다고 거르지 말자!
	//		요청파라미터 : String -> 형변환을 해서 사용
	//		문법이 길다..
//	@RequestMapping(value = "calculate.do", method = RequestMethod.GET)
//	public String CalcXY(HttpServletRequest req) {
//		int x = Integer.parseInt(req.getParameter("x"));
//		int y = Integer.parseInt(req.getParameter("y"));
//		System.out.println(x);
//		System.out.println(y);
//		return "index";
//	}
	
	// GET방식 요청파라미터(주소에) 한글처리 : Tomcat설정 (server.xml)
	//		자동으로 한글처리 할 때 어떤 방식을 쓸지...
	//		server.xml 63번줄에 URIEncoding="UTF-8"
	
	// POST방식 요청파라미터(내부...) 한글처리 : 프로젝트설정 (web.xml)
	//		JSP : 파라미터 값 읽기 전에 request.setCharacterEncoding("UTF-8");
	//		Spring : web.xml에 설정
	
	// 2. Spring 스타일 
//	@RequestMapping(value= "/calculate.do", method = RequestMethod.POST)
//	public String calcXY(@RequestParam(value="n") String n, 
//			@RequestParam(value="x") int x, @RequestParam(value="y") int y) {
//		System.out.println(n);
//		System.out.println(x);
//		System.out.println(y);
//		return "index";
//	}
	
	// 3. Spring 스타일2 - 요청파라미터를 JavaBean객체로
	@RequestMapping(value= "/calculate.do", method = RequestMethod.POST)
	public String calcXY(CalcResult cr, HttpServletRequest req) {
		cd.calculate(cr, req);
		return "index";
	}
	
	
}


















