package com.dackdoo.jan173.jstlf;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

public class JSTLFDataMaker {
	public static void make(HttpServletRequest request) {
		int a = 123456789;
		request.setAttribute("a", a);
		
		double b = 10 / 24.0;
		request.setAttribute("b", b);
		
		double c = 123.456789;
		request.setAttribute("c", c);
		
		Date now = new Date();
		request.setAttribute("d", now);
		
//		DataMaker���� 
//		String e = "2022/01/17";
//		request.setAttribute("e", e);
//		�� <fmt:formatDate>�� �ذ��� �ȵ� ����!!
	 
		
		ArrayList<Snack> snacks = new ArrayList<Snack>();
		snacks.add(new Snack("����Ĩ", 2000, new Date()));
		snacks.add(new Snack("����", 3000, new Date()));
		snacks.add(new Snack("��������", 4000, new Date()));
		snacks.add(new Snack("�����۽�", 5000, new Date()));
		request.setAttribute("s", snacks);
	}     
}
