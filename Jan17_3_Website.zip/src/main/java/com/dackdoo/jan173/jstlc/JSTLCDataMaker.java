package com.dackdoo.jan173.jstlc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

public class JSTLCDataMaker {
	public static void make(HttpServletRequest request) {
		int[] ar = {123, 456, 78, 91, 234};
		request.setAttribute("ar", ar);
		
		ArrayList<Dackdoo> al = new ArrayList<Dackdoo>();
		al.add(new Dackdoo("�ߵ�", 3, 50.2, 80.6));
		al.add(new Dackdoo("���", 5, 780.2, 180.6));
		al.add(new Dackdoo("���", 6, 80.2, 800.6));
		al.add(new Dackdoo("����", 12, 150.2, 40.6));
		request.setAttribute("al", al);
	}
}
