package com.dackdoo.jan173.calc;

import javax.servlet.http.HttpServletRequest;

public class Calc {
	
	private int plus;
	private int minus;
	private int multi;
	private int devide;
	
	private static Calc c = new Calc();
	
	public Calc() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public static Calc getC() {
		return c;
	}



	public static void setC(Calc c) {
		Calc.c = c;
	}



	public void calculator(HttpServletRequest request) {
		int x = Integer.parseInt(request.getParameter("x"));
		int y = Integer.parseInt(request.getParameter("y"));
		
		plus = x+y;
		minus = x-y;
		multi = x*y;
		devide = x/y;
		
		request.setAttribute("p", plus);
		request.setAttribute("m", minus);
		request.setAttribute("mul", multi);
		request.setAttribute("d", devide);
	}
}
