function checkValid() {
	let namechk = document.ff.name;
	let heightchk = document.ff.height;
	let weightchk = document.ff.weight;
	
	// name ��ȿ�� �˻�
	if (isEmpty(namechk) 
			|| atLeastLetter(namechk, 2)) {
		alert("Please fill in your name korean.");
		namechk.value="";
		namechk.focus();
		return false;
	}
	
	// height ��ȿ�� �˻�
	if(isEmpty(heightchk)
			|| atLeastLetter(heightchk, 6)
			|| notContains(heightchk, "0123456789")
			|| notContains(heightchk, ".")) {
		alert("Please fill in your height Properly.");
		heightchk.value="";
		heightchk.focus();
		return false;
	}
	
	// weightchk ��ȿ�� �˻�
	if(isEmpty(weightchk) 
			|| atLeastLetter(weightchk, 5)
			|| notContains(weightchk, "0123456789")
			|| notContains(weightchk, ".")) {
		alert("Please fill in your weight Properly.");
		weightchk.value="";
		weightchk.focus();
		return false;
	}
	
	return ture;
}






