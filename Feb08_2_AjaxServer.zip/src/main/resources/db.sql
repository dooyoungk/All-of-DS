create table feb08_weather(
	w_no number(3) primary key,
	w_hour varchar2(10 char) not null,
	w_day varchar2(10 char) not null,
	w_tempt varchar2(10 char) not null,
	w_tmx varchar2(10 char) not null
);

create sequence feb08_weather_seq;