package com.dackdoo.feb082.weather;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

@Service
public class WeatherDAO {
	public String getKoreaWeather(HttpServletRequest req) {
		// http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=2823756000
		try {
//			String url = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=2823756000";
//			URL u = new URL(url);
			URL u = new URL("http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=2823756000");
			HttpURLConnection huc = (HttpURLConnection) u.openConnection();
			InputStream is = huc.getInputStream();
			
//			InputStreamReader isr = new InputStreamReader(is, "UTF-8");
//			BufferedReader br = new BufferedReader(isr);
			BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			
			// 나오는 하나하나를 하나의 덩어리로 뭉치기
			StringBuffer sb = new StringBuffer();
			
			String line = null;
			while ((line = br.readLine()) != null) {
				// System.out.println(line);
				sb.append(line.replace("\r\n", "")); // enter부분 빈칸처리
			}
			
			// 다운 받아온 것을 한 덩어리로 뭉쳤고, 엔터키처리 없앰
			// System.out.println(sb.toString());
			return sb.toString();
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
