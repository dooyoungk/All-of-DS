package com.dackdoo.feb082.weather;

import java.math.BigDecimal;

public class Weather {
	private BigDecimal w_no;
	private String w_hour;
	private String w_day;
	private String w_tempt;
	private String w_tmx;
	
	public Weather() {
		// TODO Auto-generated constructor stub
	}

	public Weather(BigDecimal w_no, String w_hour, String w_day, String w_tempt, String w_tmx) {
		super();
		this.w_no = w_no;
		this.w_hour = w_hour;
		this.w_day = w_day;
		this.w_tempt = w_tempt;
		this.w_tmx = w_tmx;
	}

	public BigDecimal getW_no() {
		return w_no;
	}

	public void setW_no(BigDecimal w_no) {
		this.w_no = w_no;
	}

	public String getW_hour() {
		return w_hour;
	}

	public void setW_hour(String w_hour) {
		this.w_hour = w_hour;
	}

	public String getW_day() {
		return w_day;
	}

	public void setW_day(String w_day) {
		this.w_day = w_day;
	}

	public String getW_tempt() {
		return w_tempt;
	}

	public void setW_tempt(String w_tempt) {
		this.w_tempt = w_tempt;
	}

	public String getW_tmx() {
		return w_tmx;
	}

	public void setW_tmx(String w_tmx) {
		this.w_tmx = w_tmx;
	}
	
	
	
	
}

	