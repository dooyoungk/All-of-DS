package com.dackdoo.feb082.weather;

import java.util.List;

public interface WeatherMapper {
	public abstract List<Weather> getAllWeather();
}
