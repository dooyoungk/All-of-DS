package com.dackdoo.jan212.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

// 홈플러스 사장(부천)
//		구매금액을 입력하면 적립포인트(구매금액의 1프로) 계산하기
//		개발자 의뢰
//		-> 0.7프로로 바꿔줘!

// 개발자(선릉)
//		개발(.java) -compile-> 기계어(.class) -실행-> 테스트
//		기계어(.class) -압축-> 배포파일(.jar)[.bat] -사장님에게 전달->

// 유지보수
// IoC (Inversion Of Control) : 제어의 역전
// .java를 수정 안해도 프로그램이 수정되게

// 프로그램 -> 파일(프로그램의 결과 -> 파일에 저장) : 일반적인 흐름
// 파일 -> 프로그램(파일로 프로그램을 제어) 

public class EMMain {
	public static void main(String[] args) {
		try {
			Scanner k = new Scanner(System.in);
			System.out.print("구매 금액 : ");
			int price = k.nextInt();
			FileReader fr = new FileReader("C:/Users/wtime/Desktop/DS/pointRate.txt");
			BufferedReader br = new BufferedReader(fr);
			String pr = br.readLine();
			System.out.println("-----------------");
			System.out.printf("구매금액 : %d원\r\n", price); // bat파일에서 \n처리가 안될 수도 있어서 \r\n처리			
			double point = price * Double.parseDouble(pr);
			System.out.printf("적립포인트 : %.0f점", point);

			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
