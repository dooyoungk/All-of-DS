package com.dackdoo.jan141.main;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;

public class OE_Model {
	private int time;
	private int win;
	private int lose;
	private int coinNum;
	
	private static final OE_Model om = new OE_Model();
	
	public OE_Model() {
		// TODO Auto-generated constructor stub
	}

	public static OE_Model getOm() {
		return om;
	}
	
	public void OEgame(HttpServletRequest request) {
		int myChoice = Integer.parseInt(request.getParameter("myChoice"));
		int coinNum = new Random().nextInt(10)+1;
		
		//¦��
		int result = coinNum%2!=0 ? 1:2;
		if (myChoice==result && result==2) {
			request.setAttribute("r", "¦��");
			time++;
			win++;
		} else if (myChoice==result && result==1) {
			request.setAttribute("r", "Ȧ��");
			time++;
			win++;
		} else if (myChoice<result) {
			request.setAttribute("r", "¦��");
			time++;
			lose++;
		} else if (myChoice>result) {
			request.setAttribute("r", "Ȧ��");
			time++;
			lose++;
		}
		
		request.setAttribute("cn", coinNum);
		request.setAttribute("time", time);
		request.setAttribute("win", win);
		request.setAttribute("lose", lose);
	}
}













