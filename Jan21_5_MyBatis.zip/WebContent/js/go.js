function gowrite() {
	let txtBox = document.getElementByName("txt");
	let dateBox = document.getElementByName("date");
	alert('asdf');
	alert(txtBox.value);
	alert(dateBox.value);
	
	location.href = "MemoWriteController?txt=" + txtBox.value + "&date=" + dateBox.value;
}