create table jan23_memo(
	m_no number(4) primary key,
	m_txt varchar2(100 char) not null,
	m_enddate date not null
);

drop table jan23_memo;


create sequence jan23_memo_seq;

drop sequence jan23_memo_seq;
select * from JAN23_MEMO;