package com.dackdoo.jan215.memo;

import java.math.BigDecimal;
import java.util.Date;

public class Memo {
	private BigDecimal m_no;
	private String m_txt;
	private Date m_enddate;
	
	public Memo() {
		// TODO Auto-generated constructor stub
	}

	public Memo(BigDecimal m_no, String m_txt, Date m_enddate) {
		super();
		this.m_no = m_no;
		this.m_txt = m_txt;
		this.m_enddate = m_enddate;
	}

	public BigDecimal getM_no() {
		return m_no;
	}

	public void setM_no(BigDecimal m_no) {
		this.m_no = m_no;
	}

	public String getM_txt() {
		return m_txt;
	}

	public void setM_txt(String m_txt) {
		this.m_txt = m_txt;
	}

	public Date getM_enddate() {
		return m_enddate;
	}

	public void setM_enddate(Date m_enddate) {
		this.m_enddate = m_enddate;
	}
	
	
}
