package com.dackdoo.jan215.memo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;

import com.dackdoo.jan215.db.manager.DackdooDBManager;

public class MemoDAO {
	// select문
	public static void getMemo(HttpServletRequest req) {
		SqlSession ss = null;
		try {
			// 패키지까지 전부 명시해야!!
			ss = DackdooDBManager.connect("com/dackdoo/jan215/home/config.xml");
			
			List<Memo> memos = ss.selectList("memoMapper.getMemo");
			req.setAttribute("memos", memos);
			
//			req.setAttribute("memos", ss.selectList("memoMapper.getMemo"));	// 한줄로 나타내기
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		ss.close();
	}
	
	// insert문
	public static void write(HttpServletRequest req) {
		SqlSession ss = null;
		try {
			ss = DackdooDBManager.connect("com/dackdoo/jan215/home/config.xml");
			
			String t = req.getParameter("txt");
			t = t.replace("\r\n", "<br>");
			String d = req.getParameter("date");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date d2 = sdf.parse(d);
			
			Memo m = new Memo(null, t, d2);
			
			if (ss.insert("memoMapper.write", m) == 1) {
				req.setAttribute("r", "메모성공");
				ss.commit();	// mybatis에서는 자동 commit이 안되기 때문에 데이터에 변동이 있으면 반드시 commit을 해줘야함.
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r", "메모실패");		// 실패한 경우는 따로 commit X
		}
		ss.close();
	}
}



























