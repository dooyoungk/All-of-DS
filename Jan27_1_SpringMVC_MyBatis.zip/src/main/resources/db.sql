create table jan27_student(
	s_no number(3) primary key,
	s_name varchar2(10 char) not null,
	s_nickname varchar2(10 char) not null
);

create sequence jan27_student_seq;

drop table jan27_student cascade constraint purge;
drop sequence jan27_student_seq;
select * from JAN27_STUDENT;
-------------------------------------------

