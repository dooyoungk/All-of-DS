create table jan27_test(
	t_no number(3) primary key,
	t_name varchar2(10 char) not null,
	t_when date not null
);

drop table jan27_test cascade constraint purge;
create sequence jan27_test_seq;
drop sequence jan27_test_seq;
select * from jan27_test;