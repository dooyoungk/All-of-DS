package com.dackdoo.jan271.student;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// SqlsessionTemplate
//		Sqlsession의 하위클래스 -> Sqlsession의 기능은 다 있고, 뭔가 더 추가됨
//		자동연결/자동해제
//		자동 commit

// 변경사항
//		mapper.xml을 직접 불러서 사용 -> mapper.xml과 연결된 interface를 활용

@Service
public class StudentDAO {
	
	@Autowired
	private SqlSession ss;	//mybatis에 있는 sqlsession
	
	public void reg(Student s, HttpServletRequest req) {
		try {
			// 연결 - 자동(SqlSessionTemplate 객체 때문)
			// 값 받기 & 객체로 만들기 - Spring이 해결해놨음 - 자동
			
			// SQL문 실행 - MyBatis를 활용...
//			StudentMapper sm = ss.getMapper(StudentMapper.class);
//			
//			if (sm.regHahaha(s) == 1) {
//				req.setAttribute("r", "등록성공");
//				ss.commit();
//			}
			
			if (ss.getMapper(StudentMapper.class).regHahaha(s) == 1) {
				req.setAttribute("r", "등록성공");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r", "등록실패");
		}
//		ss.close();
	}
	public void getStdInfo(HttpServletRequest req) {
		try {
			List<Student> students = ss.getMapper(StudentMapper.class).getAllstudent();
			req.setAttribute("stds", students);		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}













