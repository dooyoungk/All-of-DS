package com.dackdoo.jan271.student;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dackdoo.jan271.test.TestDAO;

@Controller
public class StudentController {
	
	@Autowired
	private StudentDAO sDAO;
	@Autowired
	private TestDAO tDAO;
	
	@RequestMapping(value = "/student.reg", method = RequestMethod.GET)
	public String reg(Student s, HttpServletRequest req) {
		sDAO.reg(s, req);
		sDAO.getStdInfo(req);
		tDAO.getTestInfo(req);
		return "index";
	}
}
