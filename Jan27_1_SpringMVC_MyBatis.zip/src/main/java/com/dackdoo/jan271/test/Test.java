package com.dackdoo.jan271.test;

import java.util.Date;

public class Test {
	private String t_name;
	private Date t_when;

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public Test(String t_name, Date t_when) {
		super();
		this.t_name = t_name;
		this.t_when = t_when;
	}

	public String getT_name() {
		return t_name;
	}

	public void setT_name(String t_name) {
		this.t_name = t_name;
	}

	public Date getT_when() {
		return t_when;
	}

	public void setT_when(Date t_when) {
		this.t_when = t_when;
	}
}