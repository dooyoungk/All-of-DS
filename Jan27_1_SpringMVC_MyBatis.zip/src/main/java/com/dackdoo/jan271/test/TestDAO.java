package com.dackdoo.jan271.test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestDAO {
	@Autowired
	private SqlSession ss;
	
	public void exam(Test t, HttpServletRequest req) {
		
		try {
			String t_year = req.getParameter("t_year");
			int t_month = Integer.parseInt(req.getParameter("t_month"));
			int t_day = Integer.parseInt(req.getParameter("t_day"));
			
			String t_when2 = String.format("%s%02d%02d", t_year, t_month, t_day);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date t_when = sdf.parse(t_when2);
			System.out.println(t_when);
			t.setT_when(t_when);
			
			
			if (ss.getMapper(TestMapper.class).regTest(t) == 1) {
				req.setAttribute("r2", "시험등록성공");
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("r2", "시험등록실패");
		}
	}
	
	public void getTestInfo(HttpServletRequest req) {
		try {
			List<Test> tests = ss.getMapper(TestMapper.class).getAlltest();
			req.setAttribute("tests", tests);
			for (Test t : tests) {
				System.out.println(t.getT_name());
				System.out.println(t.getT_when());
				System.out.println("-----");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
