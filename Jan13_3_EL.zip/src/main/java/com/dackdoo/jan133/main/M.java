package com.dackdoo.jan133.main;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

public class M {
	public static void multiply(HttpServletRequest request) {
		int x = Integer.parseInt(request.getParameter("x"));
		int y = Integer.parseInt(request.getParameter("y"));
		int z = x * y;
		request.setAttribute("z", z);
		
		// �ƹ����Գ� �ϳ� ���� ��Ʈ����Ʈ�� ������
		Dackdoo d = new Dackdoo("�ߵ�", 28, 168.9, 68.8);
		request.setAttribute("d", d);
		
		// ��ü List
		ArrayList<Dackdoo> dds = new ArrayList<Dackdoo>();
		dds.add(d);
		dds.add(new Dackdoo("���", 27, 30.3, 50.5));
		dds.add(new Dackdoo("��ǵ�", 26, 180.3, 100.5));
		dds.add(new Dackdoo("Ģ��", 25, 190.5, 80.5));
		request.setAttribute("dds", dds);
	}
}











