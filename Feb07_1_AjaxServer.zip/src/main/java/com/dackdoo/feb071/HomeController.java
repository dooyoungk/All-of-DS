package com.dackdoo.feb071;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dackdoo.feb071.error.ErrorDAO;
import com.dackdoo.feb071.fruit.FruitDAO;

@Controller
public class HomeController {
	
	@Autowired
	private ErrorDAO eDAO;
	
	@Autowired
	private FruitDAO fDAO;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpServletRequest req) {
		eDAO.getAllError(req);
		fDAO.getAllFruit(req);
		return "index2";
	}
	
}
