package com.dackdoo.feb071.fruit;

import java.util.List;

public interface FruitMapper {
	public abstract List<Fruit> getAllFruit();
	public abstract List<Fruit> getSomeFruit(Fruit f);
}
