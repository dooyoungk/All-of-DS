create table feb07_error(
	e_what varchar2(30 char) primary key,
	e_where varchar2(30 char) not null
);

insert into feb07_error values('@빼먹음', 'DAO');
insert into FEB07_ERROR values('mapper입력 빼먹음', 'servlet-context.xml');
insert into FEB07_ERROR values('세미콜론(;) 넣음', 'mapper.xml');
insert into FEB07_ERROR values('패키지 클래스 sql', 'mapper.xml');
insert into FEB07_ERROR values('패키지 파일 위치', '프로젝트');

select * from FEB07_ERROR;
-----------------------------------------------------------------------------------
create table feb07_fruit(
	f_name varchar2(10 char) primary key,
	f_price number(5) not null
);

insert into feb07_fruit values('포도', 3200);
insert into feb07_fruit values('사과', 4800);
insert into feb07_fruit values('바나나', 5700);
insert into feb07_fruit values('레몬', 10900);
insert into feb07_fruit values('감', 4300);
insert into feb07_fruit values('키위', 8100);

select * from feb07_fruit;








