package com.dackdoo.jan071.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Calculator")
public class Calculator extends HttpServlet {
	
	// ��Ģ ���� ������
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("EUC-KR");
		
		int xInt = Integer.parseInt(request.getParameter("x"));
		int yInt = Integer.parseInt(request.getParameter("y"));
		PrintWriter pw = response.getWriter();
		
		pw.print("<html>");
		pw.print("<head><title>Calculator</title><meta charset='euc-kr'></head>");
		pw.print("<body>");
		pw.print("<table border='1'");
		pw.print("<tr><th>��Ģ����</th></tr>");
		pw.print("<tr><td>");
		pw.printf("%d + %d = %d", xInt, yInt, xInt+yInt);
		pw.print("</tr></td");
		pw.print("<tr><td>");
		pw.printf("%d - %d = %d", xInt, yInt, xInt-yInt);
		pw.print("</tr></td");
		pw.print("<tr><td>");
		pw.printf("%d * %d = %d", xInt, yInt, xInt*yInt);
		pw.print("</tr></td");
		pw.print("<tr><td>");
		pw.printf("%d �� %d = %d", xInt, yInt, xInt/yInt);
		pw.print("</tr></td");
		pw.print("</table>");
		pw.print("</body>");
		pw.print("</html>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
